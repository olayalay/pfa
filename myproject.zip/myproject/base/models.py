from django.db import models

# Create your models here.


class Users(models.Model):
    name = models.CharField(max_length=200)
    password =  models.CharField(max_length=200)
    type =  models.CharField(max_length=200)
    comments =  models.CharField(max_length=200)
    dateComment =  models.DateField(max_length=100)
class Destination(models.Model):
    name = models.CharField(max_length=200)
    description =  models.CharField(max_length=200)   
    
class travel_member(models.Model):
    firstname = models.CharField(max_length=200)
    lastname =  models.CharField(max_length=200)  
    country =  models.CharField(max_length=200)     
   
