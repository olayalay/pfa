from django.shortcuts import render,redirect
import requests
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import logout
from django.shortcuts import HttpResponseRedirect
from datetime import datetime
from base.models import travel_member
from django.http import JsonResponse

def home(request):
    data = requests.get("http://localhost:8000/api/users/").json() 
    return render(request,"home.html", {"users":len(data),"data" : data  })

   

def users(request):
    data = requests.get("http://localhost:8000/api/users/").json()  
    return render(request,"users.html",{"data":data})

def profil(request): 
    return render(request, 'profil.html')
def inscription(request): 
    return render(request, 'inscription.html')

def addmin(request):
    return render(request,'addmin.html')
def gestion(request):
    return render(request,'gestion.html')


def login(request):
    data = requests.get("http://localhost:8000/api/users/").json()  
    
    # if request.user.is_authenticated:
    #     return render(request, 'addmin.html')
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        for usr in data :
            if username.lower() == usr['name'].lower()  and password==usr['password'] :
                user = [usr['id'] , usr['name']]
                return render(request, 'home.html', {"user":user,"users":len(data),"data" : data  } )
                
                # return redirect('/addmin')    
        else :
            msg = 'Usernam or password invaled'
            # msg = data[0]['name']
            form = AuthenticationForm(request.POST)
            return render(request, 'users.html', {'form': form, 'msg': msg})
    
        # else:
        #     msg = 'Error Login'
        #     form = AuthenticationForm(request.POST)
        #     return render(request, 'users.html', {'form': form, 'msg': msg})
    else:
        form = AuthenticationForm()
        return render(request, 'users.html', {'form': form})
    

def add(request):
    date_object = datetime.now()
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        repassword = request.POST.get('repassword')
        
        # Vérification si les mots de passe correspondent
        if password != repassword:
            return render(request, 'profil.html',{"error" : "Password not mutch !"})

        # Préparation des données à envoyer dans la requête POST
        
        data = {
            "name": username,
            "password": password,
            "type": "0",
            "comments": "-",
            "dateComment":date_object.strftime('%Y-%m-%d')  
        }

        # Envoi de la requête POST à l'API Django pour insérer les données d'utilisateur
        try:
            response = requests.post("http://127.0.0.1:8000/api/users/", data=data)
            response_data = response.json()

            # Vérification si l'insertion a réussi
            if response.status_code == 201:
                return render(request, 'profil.html', {"data": response_data})  # Renvoyer les données insérées
            else:
                return JsonResponse({'error': 'Failed to insert data'}, status=response.status_code)
        except requests.exceptions.RequestException as e:
            return JsonResponse({'error': str(e)}, status=500)

    return render(request, 'profil.html',{"error":""})
        
    



def destination(request):
    return render(request, 'destination.html')
def restaurant(request):
    return render(request,'restaurant.html')
def activity(request):
    return render(request,'activity.html')
def gerer(request):
    mem=travel_member.objects.all()
    return render(request,'gerer.html',{'mem':mem})
def ADD(request):
    return render(request,'add.html')
def addrec(request):
    x=request.POST['first']
    y=request.POST['last']
    z=request.POST['country']
    mem=travel_member(firstname=x,lastname=y,country=z)
    mem.save()
    return redirect("/gerer")
def delete(request,id):
    mem=travel_member.objects.get(id=id)
    mem.delete()
    return redirect("/gerer")
def update(request,id):
    mem=travel_member.objects.get(id=id)
    return render(request,'update.html',{'mem':mem})
def uprec(request,id):
    x=request.POST['first']
    y=request.POST['last']
    z=request.POST['country']
    mem=travel_member.objects.get(id=id)
    mem.firstname=x
    mem.lastname=y
    mem.country=z
    mem.save()
    return redirect("/gerer")