from django import forms
from base.models import user
from django.contrib.auth.forms import UserCreationForm
class userForm(forms.ModelForm):
    class Meta:
        model=user
        fields = {'email','mdp'}
        widgets= {'email': forms.EmailInput(attrs={'class':  'form-control'}),
                  'mdp': forms.PasswordInput(attrs ={'class':'form-control'}),
                 }

class CustomUserCreationForm(UserCreationForm):
    password1 = forms.CharField(
        label="Password",
        strip=False,
        widget=forms.PasswordInput(attrs={'autocomplete': 'new-password'}),
    )
    password2 = forms.CharField(
        label="Password confirmation",
        widget=forms.PasswordInput(attrs={'autocomplete': 'new-password'}),
        strip=False,
    )

    class Meta(UserCreationForm.Meta):
        fields = UserCreationForm.Meta.fields + ("password1", "password2")