from django.urls import path
from . import views

urlpatterns = [
    path('users/', views.users_list),
    path('users/<int:pk>/', views.users_detail),
    
    path('destinations/', views.destinations_list),
    path('destinations/<int:pk>/', views.destinations_detail),
    path('gerer/',views.gerer),
]