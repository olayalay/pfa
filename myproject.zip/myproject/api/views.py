
import json
from rest_framework.response import Response
from django.contrib.auth import authenticate, login
from django.contrib.auth import logout
from rest_framework.decorators import api_view
from base.models import Users
from base.models import Destination
from .serializers import UsersSerializer
from .serializers import DestinationSerializer
from django.shortcuts import render,redirect
from base.models import travel_member



# -----------------------Table Users ---------------------------------

@api_view(['GET', 'POST'])
def users_list(request):
    if request.method == 'GET':
        users = Users.objects.all()
        serializer = UsersSerializer(users, many=True)
        return Response(serializer.data)
    elif request.method == 'POST':
        serializer = UsersSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)

        return Response(serializer.errors, status=400)

@api_view(['GET', 'PUT', 'DELETE'])
def users_detail(request, pk):
    try:
        user = Users.objects.get(pk=pk)
    except Users.DoesNotExist:
        return Response(status=404)

    if request.method == 'GET':
        serializer = UsersSerializer(user)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = UsersSerializer(user, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=400)

    elif request.method == 'DELETE':
        user.delete()
        return Response(status=204)
    

# -----------------------Table Destination ---------------------------------

@api_view(['GET', 'POST'])
def destinations_list(request):
    if request.method == 'GET':
        destinations = Destination.objects.all()
        serializer = DestinationSerializer(destinations, many=True)
        return Response(serializer.data)
    elif request.method == 'POST':
        serializer = DestinationSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

@api_view(['GET', 'PUT', 'DELETE'])
def destinations_detail(request, pk):
    try:
        destinations = Destination.objects.get(pk=pk)
    except Destination.DoesNotExist:
        return Response(status=404)

    if request.method == 'GET':
        serializer = DestinationSerializer(destinations)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = DestinationSerializer(destinations, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=400)

    elif request.method == 'DELETE':
        destinations.delete()
        return Response(status=204)




    
def gerer(request):
    mem=travel_member.objects.all()
    return render(request,'gerer.html',{'mem':mem})
@api_view()    
def add(request):
    return render(request,'add.html')
@api_view()   
def addrec(request):
    x=request.POST['first']
    y=request.POST['last']
    z=request.POST['country']
    mem=travel_member(firstname=x,lastname=y,country=z)
    mem.save()
    return redirect("/gerer")

    